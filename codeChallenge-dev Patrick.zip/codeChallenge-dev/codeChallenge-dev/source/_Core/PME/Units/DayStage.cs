﻿using System;

namespace PME.Units
{
    public enum DayStage
    {
        Morning,
        Afternoon,
        Evening,
        Night
    }
}
