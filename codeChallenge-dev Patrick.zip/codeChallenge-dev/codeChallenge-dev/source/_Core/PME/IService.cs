﻿using System;

namespace PME
{
    public interface IService : IRunnable 
    {
    }
}

