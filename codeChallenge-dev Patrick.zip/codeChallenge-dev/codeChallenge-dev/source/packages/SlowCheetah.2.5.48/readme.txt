SlowCheetah
===========

XML Transforms for app.config and other XML files

## Visual Studio Extension
for creating and previewing transforms:
https://marketplace.visualstudio.com/items?itemName=WillBuikMSFT.SlowCheetah-XMLTransforms

## Upgrading From Previous Versions (v2.5.15 and lower)
https://github.com/sayedihashimi/slow-cheetah/blob/master/doc/update.md
